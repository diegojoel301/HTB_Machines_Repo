Blog::Application.config.session_store :cache_store,
  :expire_after => 5.minutes
